# 天锋 AI自动化系统

![天锋](品牌资源/天锋-banner.png)

面向自媒体创作者的本地运营工作台：整理已经完成的成片、封面和文案，辅助多平台上传填写，查看排期、播放和粉丝数据。

它不生成视频。实际账号数据、平台上传和采集依赖用户登录，以及平台当前网页兼容性。

## 快速开始（macOS）

准备 Node.js 22.5+ 和 Google Chrome，下载或克隆仓库到可写目录。

```bash
python3 scripts/manage.py start
python3 scripts/manage.py open
```

也可以双击 `01_打开天锋工作台.command`。默认只监听本机 http://127.0.0.1:8787/ ，启动入口会处理首次本机访问认证。

- `02_登录平台账号.command`：打开专用浏览器，由用户登录抖音、小红书、视频号。
- `03_检查账号状态.command`：检查已配置平台的登录和页面状态。
- `04_查看演示效果.command`：打开独立演示，所有数字都是样例；禁止触发平台操作。
- `05_停止天锋服务.command`：停止工作台和演示。

启动器安装用户级 macOS LaunchAgent；电脑登录后启动，项目目录必须可用。本版本已验证 macOS arm64，本机工作台与演示页面通过浏览器检查；其他操作系统未验证。首次启动仅运行工作台，自动排期与采集任务未开启。

## 工作流程

一期一个目录放入 `发布工程/`，保存成片、封面、已确认文案。`skills/tianfeng-publish/` 提供对应 Skill，可链接到你的 Codex 技能目录；它会整理并校验 `publish.json`，按用户要求登记排期或协助上传。当前默认平台为抖音、小红书和视频号，所有平台最终发布由用户确认。

```bash
python3 scripts/manage.py tool make-publish.mjs "发布素材.md完整路径" "当期工程完整路径"
python3 scripts/manage.py tool validate.mjs "当期工程完整路径"
```

`tianfeng-publisher/` 是工作台直接使用的发布适配器。需要独立浏览器扩展时，在 Chrome 扩展程序管理页开启开发者模式并加载该目录；不要把 `sidepanel.html` 当普通网页使用。

## 本机配置与真实数据

访问口令、浏览器会话和日志位于 `~/Library/Application Support/TianfengAutomation/`，不随源码共享。首次启动生成配置；换电脑需重新登录平台。正式数据库位于 `tianfeng-workbench/data/`，演示位于 `tianfeng-workbench/demo/`，两者均被 Git 忽略。不要将自己的发布工程、登录信息或运行数据库提交到仓库。

可选通知与自有站点转化接口默认未配置。平台账号登录、真实上传/发布和采集仍需由使用者实测，页面可打开不代表这些环节已验证。

## 来源、许可证与品牌

- 工作台基于 [麦田](https://github.com/CzzzzzzJ/mdldm-maitian)，保留原作者署名和 [MIT 许可证](tianfeng-workbench/LICENSE)。
- 发布助手基于 [麦田发布助手](https://github.com/CzzzzzzJ/mdldm-maitian-publisher)，保留 [Apache-2.0 许可证](tianfeng-publisher/LICENSE)。
- 本仓库的集成脚本和天锋修改采用 [MIT](LICENSE)。上游文件仍按各自许可证使用；具体上游版本见 [来源记录](上游资料/来源.json)，改动摘要见 [NOTICE](NOTICE)。
- 天锋名称与 Logo 是品牌标识，不因代码开源自动授予品牌使用权；二次发布请换成自己的名称和图标。

本项目是基于开源项目的品牌定制与本地集成，不声明上游代码为原创。
